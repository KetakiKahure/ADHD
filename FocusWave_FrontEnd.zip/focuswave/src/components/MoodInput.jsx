import React from "react";
export default function MoodInput() {
  return <div>MoodInput Component</div>;
}